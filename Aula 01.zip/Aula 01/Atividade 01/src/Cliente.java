public class Cliente {
   String nome;
   String endereco;
   String telefone;
   String email;
}
