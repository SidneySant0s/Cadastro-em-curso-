public class Curso {
    String Nome_do_curso;
    int qtdealunos;
    String turma;
}
