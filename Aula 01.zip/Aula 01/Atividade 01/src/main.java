
public class main {
    public static void main(String[] args) {
        Cliente c;
        c = new Cliente();
        Curso cr;
        cr = new Curso();
        
        c.nome="Juvenal Josefino";
        c.endereco="Rua Palestrino, N°2";
        c.telefone="(11)98453-6782";
        
        System.out.println("Nome: " + c.nome);
        System.out.println("Endereço: " + c.endereco);
        System.out.println("Telefone: " + c.telefone);
        
       
       
        cr.Nome_do_curso= "Gestão de TI";
        cr.qtdealunos = 25 ; 
        cr.turma= "2A- noturno";
        
        System.out.println("Nome do curso: " + cr.Nome_do_curso);
        System.out.println("Quantidade de alunos: " + cr.qtdealunos + " Alunos");
        System.out.println("Turma:" + cr.turma);
        
    }
}
